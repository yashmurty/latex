1) Download and install the following ( preferably in the given order)

   MiKTEX - http://miktex.org/download                                   (Compiler for latex ) 
   Ghost script - http://www.ghostscript.com/download/gsdnld.html        (Viewer script for the output file)
   Ghost View - http://pages.cs.wisc.edu/~ghost/gsview/get50.htm         (Viewer for the output file)
   TeXnic Centre - http://www.texniccenter.org/download/                 (Editor)
   Give Ghost View as the viewer when TeXnic asks for the output viewer during installation.

2) Compile(build) groupX_report through Texnic Centre
   If error pops up saying some file/ package is missing, go to Miktex maintenence(admin)->package manager
   and select the name of the missing file from the list, go to task and click install.

3) Build and view output groupX_report to view the document which was presented by Murthy sir in class.


4) There are lots of tutorials and youtube videos available on using Latex.
